from discord.ext import commands
import discord
from discord.utils import get
import asyncio
import typing

case_insensitive = True


class Moderation(commands.Cog):
    def __init__(self, client):
        self.bot = client

    @commands.command(aliases=["purgebans", "unbanall"])
    @commands.has_permissions(administrator=True)
    async def massunban(self, ctx):
        embed2=discord.Embed(title="MassUnban", description="Unbanning All Users Please Wait", color=discord.Colour.random())
        await ctx.send(embed=embed2)
        banlist = await ctx.guild.bans()
        asyncio.sleep(3)
        for users in banlist:
            asyncio.sleep(3)
            await ctx.guild.unban(user=users.user)

    @commands.command(pass_context=True)
    @commands.has_permissions(ban_members=True) 
    async def ban(self, ctx, user: discord.Member, *, reason: str = "No reason specified"):
        server = ctx.message.server
        userID = (user.id) 
        embed = discord.Embed(title="Member Banned", color = 0xD82626)
        embed.add_field(name="Member", value="{} ".format(user) + "(<@{}>)".format(userID), inline=True)
        embed.add_field(name="Mod", value="{}".format(ctx.message.author), inline=True)
        embed.add_field(name="Reason", value="{}".format(reason), inline=False)
        embed.set_thumbnail(url=user.avatar_url)

    #   await bot.send_message(discord.Object(id=log_channel), embed=embed)
        await self.bot.ban(user)
        await self.bot.delete_message(ctx.message)  
        await user.send(f"Banned From {server}")
        await ctx.send("Banned From Guild")  
        
        
    @ban.error
    async def ban_error(self, error, ctx):
        if isinstance(error, discord.ext.commands.BadArgument):
            userID = (ctx.message.author.id)
            botMessage = await self.bot.send_message(ctx.message.channel,"<@%s>: **Sorry, I couldn't find this user**" % (userID))
            await self.bot.delete_message(ctx.message)        
            await asyncio.sleep(5)
            try:
                await self.bot.delete_message(botMessage)
            except:
                pass
        
        elif isinstance(error, discord.ext.commands.CheckFailure): # Message to the user if they don't have perms
            userID = (ctx.message.author.id)
            await self.bot.send_message(ctx.message.author,"<@%s>: **You don't have permission to perform this action**" % (userID))
            await self.bot.delete_message(ctx.message)
            
        elif isinstance(error, discord.ext.commands.CommandInvokeError):
            userID = (ctx.message.author.id)
            await self.bot.send_message(ctx.message.channel,"<@%s>: **You can't ban yourself**" % (userID))
            await self.bot.delete_message(ctx.message)
            await asyncio.sleep(5)
            try:
                await self.bot.delete_message(botMessage)
            except:
                pass
        
        
    @commands.command()
    @commands.has_permissions(ban_members = True)
    async def unban(self, ctx, id: int):
        try:
            user = await self.bot.fetch_user(id)
            await ctx.guild.unban(user)
            await ctx.send(f"{user.name} was unbanned")
        except:
            await ctx.send(f"Could Not Unban {user.name}")
                



def setup(client):
    client.add_cog(Moderation(client))