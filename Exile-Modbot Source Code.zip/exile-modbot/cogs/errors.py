import discord
import traceback
import sys
from discord.ext import commands
from colorama import Fore, Back, Style
import pymongo






class errors(commands.Cog, command_attrs=dict(hidden=True)):

    def __init__(self, client):
        self.client = client



    @commands.Cog.listener()
    async def on_command_error(self, ctx, error):
        if hasattr(ctx.command, 'on_error'):
            return

        cog = ctx.cog
        if cog:
            if cog._get_overridden_method(cog.cog_command_error) is not None:
                return

        error = getattr(error, 'original', error)

        if isinstance(error, commands.UserNotFound):
            embed = discord.Embed(
                title=f"Error | Blacklisted",
                description=f"You are currently blacklisted from the bot.")
            embed.set_author(
                name=ctx.author, icon_url=ctx.author.avatar_url)

            await ctx.send(embed=embed)

        elif isinstance(error, pymongo.errors.DuplicateKeyError):
            await ctx.send(f"The user has already been blacklisted.")

        else:
            print('Ignoring exception in command {}:'.format(
                ctx.command), file=sys.stderr)
            traceback.print_exception(
                type(error), error, error.__traceback__, file=sys.stderr)


def setup(client):
    client.add_cog(errors(client))
