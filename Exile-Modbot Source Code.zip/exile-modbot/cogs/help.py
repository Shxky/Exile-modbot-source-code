import discord
from discord.ext import commands
from discord.utils import get

case_insensitive = True


class Help(commands.Cog):
    def __init__(self, client):
        self.bot = client

    @commands.group(invoke_without_command=True)
    async def help(self, ctx):
        embed=discord.Embed(title="Help", description="For More Info On Commands Please Dm Either\n****** or ******\nFor Bot statistics just do ***ex!botinfo***", color=0x0008ff)
        embed.set_author(name="Exile Commands", icon_url=f"{ctx.author.avatar_url}")
        embed.add_field(name="__Informative Commands__", value="`invite`, `botinfo`, `serverinfo`, `whois`, `ping`\n`servers`, `users`, `membercount`, `privacy`", inline=False)
        embed.add_field(name="__Misc Commands__", value="Coming Soon", inline=False)
        embed.add_field(name="__Moderation Commands__", value="`unbanall`, `unban`, `ban`", inline=False)
        embed.add_field(name="__Support Commmands__", value=f"`bugreport`, `contact`, `supportserver`")
        embed.set_footer(text="Prefix Is ex!")
        await ctx.send(embed=embed)


def setup(client):
    client.add_cog(Help(client))