import discord
from discord.ext import commands
from discord.utils import get
import asyncio
import datetime

case_insensitive = True


class General(commands.Cog):
    def __init__(self, client):
        self.bot = client


    @commands.command()
    async def whois(self, ctx, member: discord.Member = None):
        member = ctx.author if not member else member

        roles = [role for role in member.roles]

        embed = discord.Embed(color=discord.Colour.random(), timestamp=ctx.message.created_at)
        embed.set_author(name=f"Account Name | {member}")
        embed.add_field(name="Server Nickname", value=member.display_name)
        embed.add_field(
            name="Account Creation Date",
            value=member.created_at.strftime("%a, %d %B %Y, %I:%M %p UTC"))
        embed.add_field(
            name="Member Joined At",
            value=member.joined_at.strftime("%a, %d %B %Y, %I:%M %p UTC"))
        embed.add_field(
            name=f"Roles({len(roles)})",
            value=" ".join([role.mention for role in roles]))
        embed.set_thumbnail(url=member.avatar_url)
        embed.set_footer(text=f"requested by {ctx.author}")
        await ctx.send(embed=embed)

    @commands.command()
    async def botinfo(self, ctx):
        embed = discord.Embed(title="Exile Bot info!", color=discord.Colour.random())
        embed.add_field(name="🔹 __Version:__", value=f"Version 1.0.15",inline=True)
        embed.add_field(name=f"<:verifiedBot1:816961986809167902> __Commands:__", value=f"`{len(self.bot.commands)} Commands!`", inline=True)
        embed.add_field(name=f"<a:bcminor:816961539872653312> __Ping:__", value=f"`{round(self.bot.latency * 1000)}ms`", inline=True)
        embed.add_field(name="<:728216184738021376:816962130275598346> __Users & Servers__", value=f"`{len(self.bot.users)} Users!`\n`{len(self.bot.guilds)} Servers!`", inline=True)
        embed.add_field(name="📚 __Library:__", value=f"`Python`", inline=True)
        embed.add_field(name="<:e63co024yh741:816960848152231977> __Creators:__", value="`******`", inline=True)
        await ctx.send(embed=embed)
    
    
    @commands.command()
    async def servers(self, ctx):
        embed=discord.Embed(title="Exile Bot servers", description="", color=discord.Colour.random())
        embed.add_field(name="__Servers__", value=f"{len(self.bot.guilds)}", inline=False)
        await ctx.send(embed=embed)
        
    @commands.command()
    async def  privacy(self, ctx):
        embed=discord.Embed(title="Contact The Developers", description="We do not store any data because we do not need to all of our commands are done by reading data if you have any concerns please get in touch below", color=discord.Colour.random())
        embed.add_field(name="Email address", value="******", inline=True)
        embed.add_field(name="Support Server", value="[Server Invite](******)")
        embed.add_field(name="Discord Names", value="******", inline=False)
        await ctx.send(embed=embed)
        
    @commands.command()
    async def users(self, ctx):
        embed=discord.Embed(title="Exile Bot users", description="", color=discord.Colour.random())
        embed.add_field(name="__Users__", value=f"{len(self.bot.users)}", inline=False)
        await ctx.send(embed=embed)

    @commands.command(aliases=["Membercount"])
    async def membercount(self, ctx):
        embed = discord.Embed(
            description=f"{ctx.guild.member_count} Total Users",
            color=discord.Colour.random())
        await ctx.send(embed=embed)

    @commands.command(aliases=["inv"], pass_context=True)
    async def invite(self, ctx):
        embed = discord.Embed(
            color=discord.Colour.random(),
            description=
            "[invite](******)")
            
        embed.set_footer(text=f"Requested by {ctx.author}")
        await ctx.send(embed=embed)
    @commands.command(aliases=["Support"], pass_context=True)
    async def supportserver(self, ctx):
        embed = discord.Embed(
            color=discord.Colour.random(),
            description=
            "__Join Elite Development Support Server__\n******")
            
        embed.set_footer(text=f"Requested by {ctx.author}")
        await ctx.send(embed=embed)
   
  
        
    @commands.command(pass_context=True)
    async def serverinfo(self, ctx):
        a = ctx.guild.member_count
        date_format = "%a, %d %b %Y %I:%M %p"
        embed = discord.Embed(title=f"{ctx.guild.name}", description=f"{a} Members\n {len(ctx.guild.roles)} Roles\n {len(ctx.guild.text_channels)} Text-Channels\n {len(ctx.guild.voice_channels)} Voice-Channels\n {len(ctx.guild.categories)} Categories", timestamp=datetime.datetime.utcnow(), color=discord.Colour.random())
        embed.add_field(name="Server created at", value=f"{ctx.guild.created_at.strftime(date_format)}", inline=False)
        embed.add_field(name="Server Owner", value=f"{ctx.guild.owner}", inline=False)
        embed.add_field(name="Server Region", value=f"{ctx.guild.region}", inline=False)
        embed.add_field(name="Server ID", value=f"{ctx.guild.id}", inline=False)
        embed.set_thumbnail(url=f"{ctx.guild.icon_url}")
        embed.set_footer(text=f"requested by {ctx.author}")
        await ctx.send(embed=embed)
      
    @commands.command(pass_context=True)
    async def ping(self, ctx):
        ping = round(self.bot.latency * 1000)
        embed=discord.Embed(title="Ping", description="My Connection To discord", color=discord.Colour.random())
        embed.add_field(name="__Client Latency__", value=f"`{ping}ms`", inline=False)
        await ctx.send(embed=embed)


 

def setup(client):
    client.add_cog(General(client))