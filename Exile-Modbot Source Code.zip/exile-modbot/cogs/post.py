import discord
from discord.ext import commands, tasks
from discord.utils import get
import requests
import json
from discord.ext.tasks import loop
import aiohttp



class post(commands.Cog):
    def __init__(self, client):
        self.bot = client
        self.discord_bot_list_url = "******"
        self.bots_id = 804398559046795264
        self.discord_bot_list_auth = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ0IjoxLCJpZCI6IjgwNDM5ODU1OTA0Njc5NTI2NCIsImlhdCI6MTYxNDY5ODI4MH0.iRJ3ZUji5Ln99-7m2HQtyOakBlbtqRHQ92QLLXAETmQ"
        self.del_update_stats.start()

    
    
    @tasks.loop(minutes=5.0)
    async def del_update_stats(self):
        """ This automatically updates your server count to Discord Extreme List every 30 minutes. """
        await self.bot.wait_until_ready()
        async with aiohttp.ClientSession() as session:
            async with session.post(f'https://api.discordextremelist.xyz/v2/bot/{self.bot.user.id}/stats',
            headers={'Authorization': 'DELAPI_7f1c88dbfefd0ecd6e0c46d874da8bac-804398559046795264', # Make sure you put your API Token Here
            "Content-Type": 'application/json'},
            data=json.dumps({'guildCount': len(self.bot.guilds)
            })) as r:
                js = await r.json()
                if js['error'] == True:
                    print(f'Failed to post to discordextremelist.xyz\n{js}')
                    payload = {'guilds': len(self.bot.guilds), 'users': len(self.bot.users)}
                    header = {"content-type": "application/json", "Authorization": self.discord_bot_list_auth}
                    discordbotlistresponse = requests.post(self.discord_bot_list_url, headers=header,data=json.dumps(payload))
                    system = discord.Webhook.partial(
                        "814797268045398026",
                        "IFpkbwJ4e-WRvL0XRbszKBkM6cu8plHKZr2myj9njZJKno24NNBB09xPUup4IgkpoGiw",
                        adapter=discord.RequestsWebhookAdapter(),)
                    system.send(discordbotlistresponse)

def setup(client):
    client.add_cog(post(client))