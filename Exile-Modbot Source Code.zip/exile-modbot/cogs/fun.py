import discord
import traceback
import sys
from discord.ext import commands
from colorama import Fore, Back, Style
import pymongo






class fun(commands.Cog):

    def __init__(self, client):
        self.client = client

    @commands.command()
    async def bam(self, ctx, member: discord.Member, *, reason=None):
        if reason is None:
            embed = discord.Embed(
                title="🔨 Bammed 🔨",
                description=f"Bro got hit with that quick bam from {ctx.author.mention}"
            )
            await ctx.send(embed=embed)
            dm_embed = discord.Embed(
                title="🔨 Bammed 🔨",
                description=f"You got bammed in {ctx.guild.name} by {ctx.author}, time to get revenge? 😏"
            )
            await member.send(dm_embed)
        if reason is not None:
            embed = discord.Embed(
                title="🔨 Bammed 🔨",
                description=f"{ctx.author.mention} bammed {member.mention} for '{reason}'!! :0"
            )
            await ctx.send(embed=embed)
            dm_embed = discord.Embed(
                title="🔨 Bammed 🔨",
                description=f"You got bammed in {ctx.guild.name} by {ctx.author} for '{reason}', time to get revenge? 😏"
            )
            await member.send(dm_embed)


def setup(client):
    client.add_cog(fun(client))
