
from discord.embeds import Embed
import pymongo
import discord
from discord.ext import commands
from discord.utils import get
import datetime

case_insensitive = True


class blacklist(commands.Cog):
    def __init__(self, client):
        self.bot = client

    @commands.group(invoke_without_command=True)
    async def blacklist(self, ctx):
        embed = discord.Embed(
            title="Blacklist Panel!",
            description="How to Blacklist:\nex!blacklist add @user - Adds a user to blacklist\nex!blacklist remove userid - Removes a user id from blacklist\nex!blacklist check userid - Checks a user's blacklist status"
        )
        await ctx.send(embed=embed)


    @blacklist.command()
    @commands.is_owner()
    async def add(self, ctx, id, args, *, reason=None):
        if reason is None:
            embed = discord.Embed(title="Error", description="Enter A Reason")
            await ctx.send(embed=embed)
        else:
            myclient = pymongo.MongoClient("mongodb://mongoadmin:Carnage2701@209.145.54.160:25609/admin")
            mydb = myclient["exile"]
            mycol = mydb["blacklist"]
            now = datetime.datetime.now()
            App = args
            mydict = {"_id": f"{id}", "blacklisted": "true", "appealable": f"{App}", "Reason": f"{reason}", "time": "{now}"}
            x = mycol.insert_one(mydict)
            x
            embed = discord.Embed(
                title="Blacklisted User",
                description=f"```py\n|                BLACKLIST SYSTEM       \n+----------+----------------------------+\n| Info   	    | Input                 \n+----------+----------------------------+			\n| DiscordID     | {id}		\n| Reason        | {reason}	\n| Time          | {now}\n| Appealable    | {App}\n+---------------------------------------+\n\n```   ",
            )
            await ctx.send(embed=embed)

    @blacklist.command()
    @commands.is_owner()
    async def check(self, ctx, id=None):
        if id == None:
            embed = discord.Embed(title="Error", description="Give a user ID!")
            await ctx.send(embed=embed)
        
        else:
            myclient = pymongo.MongoClient("mongodb://mongoadmin:Carnage2701@209.145.54.160:25609/admin")
            mydb = myclient["exile"]
            mycol = mydb["blacklist"]
            x = mycol.find_one({"_id" : f"{id}"})
            if x is None:
                embed = discord.Embed(title="User Blacklist Status", description=f"{id} is currently **__Not__** blacklisted from using the bot.")
                embed.set_footer(text="Make sure you gave the user id, not mentioned them!")
                await ctx.send(embed=embed)
            elif x is not None:
                embed = discord.Embed(title="User Blacklist Status", description=f"🔴USER IS BLACKLISTED🔴")
                await ctx.send(embed=embed)

    @blacklist.command()
    @commands.is_owner()
    async def remove(self, ctx, id = None):
        if id==None:
            embed = discord.Embed(title="Error", description="Give a user ID!")
            await ctx.send(embed=embed)
        else:
            myclient = pymongo.MongoClient("mongodb://mongoadmin:Carnage2701@209.145.54.160:25609/admin")
            mydb = myclient["exile"]
            mycol = mydb["blacklist"]
            myquery = { "_id" : f"{id}" }
            mycol.delete_one(myquery)
            embed = discord.Embed(
                title="Unblacklisted User",
                description=f"User ID: {id}"
            )
            await ctx.send(embed=embed)

def setup(client):
    client.add_cog(blacklist(client))