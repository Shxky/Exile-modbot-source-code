import discord
import asyncio
import random
from discord.ext.commands.errors import CommandInvokeError
import discord.utils
import time
import datetime
from discord.ext import commands
from discord.utils import find
from discord.ext.commands import Bot
from discord.ext import tasks
import ibl
from discord import permissions
from discord import ChannelType, Colour, Embed, Guild, Message, Role, Status, utils
import datetime
import aiohttp
import io
import requests
import json
import pymongo





######################################################################
##                           TO-DO List                             ##                 
######################################################################

# modmail
# report problems to a webhook
# record suggestions from external servers to a webhook
# make the premium version
# learn mongodb or mysql
# do the bwh system



token = ("ODA0Mzk4NTU5MDQ2Nzk1MjY0.YBLwiQ.O-3Ko0RD5XU2n9CtEr18lhDT0fM")
prefix = ("ex!!")
client = commands.AutoShardedBot(command_prefix=prefix, intents=discord.Intents.all())
client.remove_command('help')




@client.check
def blacklisted(ctx):
    myclient = pymongo.MongoClient("mongodb://mongoadmin:Carnage2701@209.145.54.160:25609/admin")
    mydb = myclient["exile"]
    mycol = mydb["blacklist"]
    x = mycol.find_one({"_id": f"{ctx.author.id}", "blacklisted": "true"})
    if x is None:
        return True
    else:
        raise commands.UserNotFound(f"{ctx.author.id}")

	
async def status_task():
	while True:
		await client.change_presence(
		    status=discord.Status.online,
		    activity=discord.Activity(
		        type=discord.ActivityType.streaming, name=f"I am in {len(client.guilds)} servers!"))
		await asyncio.sleep(5)
		await client.change_presence(
		    status=discord.Status.online,
		    activity=discord.Activity(
		        type=discord.ActivityType.streaming,
		        name=
		        f"Made by | ******"))
		await asyncio.sleep(5)
		await client.change_presence(
		    status=discord.Status.online,
		    activity=discord.Activity(
		        type=discord.ActivityType.streaming,
		        name=f"{prefix} is the prefix"))
		await asyncio.sleep(5)
		await client.change_presence(
		    status=discord.Status.online,
		    activity=discord.Activity(
		        type=discord.ActivityType.streaming,
		        name=f"{round(client.latency * 1000)}ms Ping"))
		await asyncio.sleep(5)
        
        


        
        
        
@client.event
async def on_ready():
	print(f"{client.user} Is Now Online!")
	await status_task()



system = discord.Webhook.partial(
    "814797268045398026",
    "IFpkbwJ4e-WRvL0XRbszKBkM6cu8plHKZr2myj9njZJKno24NNBB09xPUup4IgkpoGiw",
    adapter=discord.RequestsWebhookAdapter(),)


@client.event
async def on_guild_join(guild):
    ping = f'**My Ping is Around {round(client.latency * 1000)}ms**'
    embed=discord.Embed(title="`Joined Guild:`", description=f"> ***__{guild.name}__*** + {guild.id}", color=discord.Colour.random())
    embed.add_field(name="```Member Count:```", value=f"```{guild.member_count}```", inline=False)
    embed.add_field(name="```Owner:```", value=f"{guild.owner} - {guild.owner_id}", inline=False)
    embed.add_field(name="```Online Member Count:```", value=sum(member.status!=discord.Status.offline and not member.bot for member in guild.members))
    embed.add_field(name="```Server Count:```", value=f"{len(client.guilds)} Servers!", inline=True)
    embed.add_field(name="```Current Latency```", value=f'{ping}', inline=False)
    embed.set_thumbnail(url=f"{guild.icon_url}")
    system.send(embed=embed)
    auth = "MUY72ewtiDsXZNpUd4jGPdKbyaMBScvuEHnYsgVF8K2mslkfq8NvGZORS9vw2IrCdvKhKKDseptDJXAeDsOOXReAqfc9NUXUts5B"
    await ibl.post_stats(client.user.id, auth, len(client.guilds), shards=0)
    system.send("UPDATED INFINITY STATS")
@client.event
async def on_connect():
    ping = f'**My Ping is Around {round(client.latency * 1000)}ms**'
    embed=discord.Embed(title="Exile Is Now online", description=f"{ping} with {len(client.shards)} shards", color=discord.Colour.random())
    system.send(embed=embed)
MODULES = ['cogs.information', 'cogs.help', 'cogs.moderation', 'cogs.post', 'cogs.blacklist', 'cogs.fun', 'cogs.errors']

for module in MODULES:
    client.load_extension(module)

@client.command()
async def contact(ctx):
    embed=discord.Embed(title="Contact The Developers", description="Get In Touch For Serious Enquires only", color=discord.Colour.random())
    embed.add_field(name="Email address", value="******", inline=True)
    embed.add_field(name="Support Server", value="[Server Invite](******)")
    embed.add_field(name="Discord Names", value="******", inline=False)
    await ctx.send(embed=embed)
    
    
    
bughook = discord.Webhook.partial(
    "816080584962998293",
    "2BREEPJt4mwM6HVEoYqm3mBiY7AHe9rFRcnipX6bEYErlobm94U6kbM8QFKfysuuj2J5",
    adapter=discord.RequestsWebhookAdapter(),)
@client.command()
async def bugreport(ctx, *, bug = None):
    if bug == None:
        embed = discord.Embed(title="Error!", description="Please give a bug in the report!")
        await ctx.send(embed=embed)
    else:
        await ctx.send("Submitting the report!")
        embed = discord.Embed(title="Bug Report", description=f"Reported by {ctx.message.author} from {ctx.guild.name}")
        embed.add_field(name="Issue:", value=f"***{bug}***")
        bughook.send(embed=embed)
        bughook.send("@everyone")
    


    
client.run(token, bot=True)
